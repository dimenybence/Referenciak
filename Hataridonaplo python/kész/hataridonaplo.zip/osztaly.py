class Esemeny:
    def __int__(self, datum = None, ido = None, helyszin = None, elnevezes = None, megjegyzes = None):
        self.datum = datum
        self.ido = ido
        self.helyszin = helyszin
        self.elnevezes = elnevezes
        self.megjegyzes = megjegyzes
